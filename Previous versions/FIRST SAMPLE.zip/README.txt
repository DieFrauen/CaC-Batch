FIRST SAMPLE limited offer

CONTENTS

FIRST SAMPLE cdb (card database) file
high definition renditions of the cards (6)
pics folder (6)
scripts folder (6)

Here are the first batch of cards released for this exclusive offer, 5 cards each for the first 3 clients to order. They are as follows.

Client 1: Arc Des
- Light Magician               /46990001 (NEW - 11/27/2022)
-                              /46990002
-                              /46990003
-                              /46990004
-                              /46990005

Client 2: BlazeFenix
- Infernal King Spectri-Oh     /46990006 (NEW - 11/27/2022)
- Firetruck Monkey Business    /46990007 (NEW - 11/27/2022)
- Ghoti Starlight              /46990008 (NEW - 11/27/2022)
- Ghoti Genesis                /46990009 (NEW - 11/27/2022)
- Azzar - Elegance of the Ghoti/46990010 (NEW - 11/27/2022)

Client 3:
-                              /46990011
-                              /46990012
-                              /46990013
-                              /46990014
-                              /46990015

HOW TO USE

In order to register these cards in your YGOPro build, you should extract the contents in this Zip file into your Expansions folder, the pictures and scripts for each card go in their respective folders along with all other files from different expansions. Make sure to check your repositories and everything else is in order. To play cards in Expansion files online with friends, you must use the LAN + AI mode, as these contents are not available in Server based duels.

Thanks for your patronage.

Die Frauen 2022

All stock images used for these cards were retrieved from online sources throughout the web and are intended to be free and fair use, if you find that your, or someone's work is used here, feel free to provide source information to be listed below or to request its takedown.

STOCK IMAGE SOURCES

Light Magician - AviArts / https://www.reddit.com/user/ThePeachyPanda/
Infernal King Spectri-Oh - Pyron - Darkstalkers / source pending 

Yugioh card editor
GUI by Lauqerm / https://lauqerm.github.io/ygocarder/